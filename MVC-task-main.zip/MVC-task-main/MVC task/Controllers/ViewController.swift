//
//  ViewController.swift
//  MVC task
//
//  Created by Macintosh on 22/12/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var emailId: UITextField!
    @IBOutlet weak var password: UITextField!
    
    let users = [Users].self
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    @IBAction func nxtBtn(_ sender: Any) {
        print("User LogedIn")
    }

}

