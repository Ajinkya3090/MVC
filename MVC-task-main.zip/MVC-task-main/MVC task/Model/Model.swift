//
//  Model.swift
//  MVC task
//
//  Created by Macintosh on 22/12/21.
//

import Foundation

struct Users {
    let emailId : String
    let password : String
}
